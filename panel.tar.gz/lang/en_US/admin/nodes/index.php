<?php

return [
    'create_node' => 'Create Node',
    'create_modal' => [
        'title' => 'Create a Node',
    ],

    'location_group' => 'Location Group',
    'pve_name' => 'Node Name In Proxmox',
    'override_creds' => 'Override credentials',
    'creds_warning' => 'Please disable privilege separation and grant root privileges.',
    'token_id' => 'Token ID',
    'secret' => 'Secret',
    'memory_allocation' => 'Memory Allocation',
    'memory_overallocation' => 'Memory Overallocation',
    'disk_allocation' => 'Disk Allocation',
    'disk_overallocation' => 'Disk Overallocation',
    'vm_storage' => 'VM Storage',
    'backup_storage' => 'Backup Storage',
    'iso_storage' => 'ISO Storage',

    'create_template_modal' => [
        'title' => 'Create a Template',
    ],
    'new_template' => 'New Template',
    'create_template_group_modal' => [
        'title' => 'Create a Template Group',
    ],
    'new_template_group' => 'New Template Group',

    'node_info' => [
        'title' => 'Node Information',
    ],
    'delete_node' => [
        'title' => 'Delete Node',
        'description' => 'The node will be permanently deleted from Convoy. This action is irreversible and can not be undone.',
        'has_servers_error' => 'You cannot delete a node that has servers assigned to it.',
    ],
];
